#pragma once
class FFTTest
{
public:
	FFTTest();
	~FFTTest();
	void run();
	void runSymmetryTest();
};

