#pragma once
class TIRBMTest
{
public:
	TIRBMTest();
	~TIRBMTest();
	void runTest();
	void runMnist();
};

