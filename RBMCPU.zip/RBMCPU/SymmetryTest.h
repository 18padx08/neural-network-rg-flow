#pragma once
class SymmetryTest
{
public:
	SymmetryTest();
	~SymmetryTest();
	void runSymmetryTest();
};

