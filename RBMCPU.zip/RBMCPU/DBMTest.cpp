#include "DBMTest.h"



DBMTest::DBMTest()
{
}


DBMTest::~DBMTest()
{
}

void DBMTest::runDMTest()
{
}
