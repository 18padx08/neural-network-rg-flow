#pragma once
class MNISTTest {
public:
	MNISTTest();
	void executeRBMCPU();
	void loadWeightsRBMCPU();
	void intenseTest();
	void DBNTest();
};
