#pragma once
class RG
{
public:
	RG();
	~RG();
	void runRG();
	void runDBN();
};

