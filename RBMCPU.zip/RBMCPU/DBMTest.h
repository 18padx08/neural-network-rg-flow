#pragma once
#include "DBM.h"
class DBMTest
{
public:
	DBMTest();
	~DBMTest();
	void runDMTest();
};

