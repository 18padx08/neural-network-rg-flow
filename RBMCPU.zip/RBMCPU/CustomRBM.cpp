#include "CustomRBM.h"



CustomRBM::CustomRBM()
{
}


CustomRBM::~CustomRBM()
{
}

void CustomRBM::setWeights(vector<double> weights)
{
}

void CustomRBM::parseConfig(string filename)
{
}
