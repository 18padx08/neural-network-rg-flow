#pragma once
class AnalyticalTest
{
public:
	void runTest();
	void runAnalytical();
};

