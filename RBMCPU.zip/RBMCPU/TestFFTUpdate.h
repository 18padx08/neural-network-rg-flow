#pragma once
class TestFFTUpdate
{
public:
	TestFFTUpdate();
	~TestFFTUpdate();
	void run();
	void runFFTCompareToNewHidden();
};

